INSERT INTO courier_centre (id, name, address_line1, pin_code_id, latitude, longitude)
VALUES (0, 'Online', 'Internet', '1_226001', 0, 0);
INSERT INTO courier_centre (id, name, address_line1, pin_code_id, latitude, longitude)
VALUES (1, 'Indraprastha', 'Karol Bagh', '1_110005', 28.5479, 77.2031);
INSERT INTO courier_centre (id, name, address_line1, pin_code_id, latitude, longitude)
VALUES (2, 'Avadh', 'Hazratganj', '1_226001', 26.8537, 80.9484);
INSERT INTO courier_centre (id, name, address_line1, pin_code_id, latitude, longitude)
VALUES (3, 'Vidarbha', 'Santacruz', '1_400055', 19.0843, 72.8360);
INSERT INTO courier_centre (id, name, address_line1, pin_code_id, latitude, longitude)
VALUES (4, 'Madra', 'Ramapuram', '1_600089', 13.0106, 80.1932);
INSERT INTO courier_centre (id, name, address_line1, pin_code_id, latitude, longitude)
VALUES (5, 'Angademan', 'Marine Jetty', '1_744101', 11.6671, 92.7404);


INSERT INTO centre_contact (phone, department, centre_id)
VALUES ('1800-400-300', 'Customer Care', 0);
INSERT INTO centre_contact (phone, department, centre_id)
VALUES (TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'Reception', 1);
INSERT INTO centre_contact (phone, department, centre_id)
VALUES (TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'Corporate Helpdesk', 1);
INSERT INTO centre_contact (phone, department, centre_id)
VALUES (TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'Enquiry Office', 1);
INSERT INTO centre_contact (phone, department, centre_id)
VALUES (TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'Reception', 2);
INSERT INTO centre_contact (phone, department, centre_id)
VALUES (TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'Corporate Helpdesk', 2);
INSERT INTO centre_contact (phone, department, centre_id)
VALUES (TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'Reception', 3);
INSERT INTO centre_contact (phone, department, centre_id)
VALUES (TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'Corporate Helpdesk', 3);
INSERT INTO centre_contact (phone, department, centre_id)
VALUES (TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'Reception', 4);
INSERT INTO centre_contact (phone, department, centre_id)
VALUES (TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'Corporate Helpdesk', 4);
INSERT INTO centre_contact (phone, department, centre_id)
VALUES (TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'Reception', 5);
