INSERT INTO vehicle (id, vehicle_number, date, source_city_id, type)
VALUES (1, '6E | 2051', CURRENT_DATE(), 13, 'AIRPLANE');
INSERT INTO vehicle_destination (vehicle_id, city_id) VALUES (1, 101);
INSERT INTO vehicle_destination (vehicle_id, city_id) VALUES (1, 105);

INSERT INTO vehicle (id, vehicle_number, date, source_city_id, type)
VALUES (2, '12495', CURRENT_DATE(), 101, 'TRAIN');
INSERT INTO vehicle_destination (vehicle_id, city_id) VALUES (2, 6017);
INSERT INTO vehicle_destination (vehicle_id, city_id) VALUES (2, 6003);
INSERT INTO vehicle_destination (vehicle_id, city_id) VALUES (2, 7);

INSERT INTO vehicle (id, vehicle_number, date, source_city_id, type)
VALUES (3, 'UP32 FC 1946', CURRENT_DATE(), 6017, 'TRUCK');
INSERT INTO vehicle_destination (vehicle_id, city_id) VALUES (3, 6);

INSERT INTO vehicle (id, vehicle_number, date, source_city_id, type)
VALUES (4, 'M.V.HARSHAVARDHANA', CURRENT_DATE(), 11, 'SHIP');
INSERT INTO vehicle_destination (vehicle_id, city_id) VALUES (4, 102);

INSERT INTO vehicle (id, vehicle_number, date, source_city_id, type)
VALUES (5, '6E | 2051', CURRENT_DATE()+1, 13, 'AIRPLANE');
INSERT INTO vehicle_destination (vehicle_id, city_id) VALUES (5, 101);
INSERT INTO vehicle_destination (vehicle_id, city_id) VALUES (5, 105);

INSERT INTO vehicle (id, vehicle_number, date, source_city_id, type)
VALUES (6, '12495', CURRENT_DATE()+2, 101, 'TRAIN');
INSERT INTO vehicle_destination (vehicle_id, city_id) VALUES (6, 6017);
INSERT INTO vehicle_destination (vehicle_id, city_id) VALUES (6, 6003);
INSERT INTO vehicle_destination (vehicle_id, city_id) VALUES (6, 7);

INSERT INTO vehicle (id, vehicle_number, date, source_city_id, type)
VALUES (7, 'UP32 FC 1946', CURRENT_DATE()+2, 6017, 'TRUCK');
INSERT INTO vehicle_destination (vehicle_id, city_id) VALUES (7, 6);

INSERT INTO vehicle (id, vehicle_number, date, source_city_id, type)
VALUES (8, 'M.V.HARSHAVARDHANA', CURRENT_DATE()+5, 11, 'SHIP');
INSERT INTO vehicle_destination (vehicle_id, city_id) VALUES (8, 102);