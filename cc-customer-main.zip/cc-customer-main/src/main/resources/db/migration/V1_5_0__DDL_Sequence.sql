CREATE SEQUENCE sq_courier_centre_id
    START 10
    INCREMENT 1;

CREATE SEQUENCE sq_app_user_id
    START 100010
    INCREMENT 1;

CREATE SEQUENCE sq_consignment_status_id
    START 100
    INCREMENT 1;

CREATE SEQUENCE sq_vehicle_id
    START 10
    INCREMENT 1;
