CREATE TABLE courier_centre (
    id                      INTEGER             NOT NULL,
    name                    VARCHAR(50)         NOT NULL,
    address_line1           VARCHAR(100)        NOT NULL,
    address_line2           VARCHAR(100),
    pin_code_id             VARCHAR(20)         NOT NULL,
    latitude                DOUBLE PRECISION    NOT NULL,
    longitude               DOUBLE PRECISION    NOT NULL,
    CONSTRAINT pk_courier_centre_id
        PRIMARY KEY (id),
    CONSTRAINT fk_courier_centre_pin_code_id
        FOREIGN KEY (pin_code_id)
            REFERENCES pin_code
);

CREATE TABLE centre_contact (
    phone                   VARCHAR(20)         NOT NULL,
    department              VARCHAR(50)         NOT NULL,
    centre_id               INTEGER             NOT NULL,
    CONSTRAINT pk_centre_contact_phone
        PRIMARY KEY (phone),
    CONSTRAINT fk_centre_contact_centre_id
            FOREIGN KEY (centre_id)
                REFERENCES courier_centre
);
