CREATE TABLE vehicle (
    id                      BIGINT              NOT NULL,
    vehicle_number          VARCHAR(20)         NOT NULL,
    date                    DATE                NOT NULL,
    source_city_id          INTEGER             NOT NULL,
    type                    VARCHAR(20)         NOT NULL,
    CONSTRAINT pk_vehicle_id
        PRIMARY KEY (id),
    CONSTRAINT uk_vehicle_vehicle_number_date
        UNIQUE (vehicle_number, date),
    CONSTRAINT fk_vehicle_source_city_id
        FOREIGN KEY (source_city_id)
            REFERENCES city
);

CREATE TABLE vehicle_destination (
    vehicle_id              BIGINT              NOT NULL,
    city_id                 INTEGER             NOT NULL,
    CONSTRAINT pk_vehicle_destination_vehicle_id_city_id
        PRIMARY KEY (vehicle_id, city_id),
    CONSTRAINT fk_vehicle_destination_vehicle_id
        FOREIGN KEY (vehicle_id)
            REFERENCES vehicle,
    CONSTRAINT fk_vehicle_destination_city_id
        FOREIGN KEY (city_id)
            REFERENCES city
);