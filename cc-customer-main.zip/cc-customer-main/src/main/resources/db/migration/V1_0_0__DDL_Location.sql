CREATE TABLE country (
    id                      INTEGER             NOT NULL,
    name                    VARCHAR(50)         NOT NULL,
    CONSTRAINT pk_country_id
        PRIMARY KEY (id)
);

CREATE TABLE state (
    id                      INTEGER             NOT NULL,
    name                    VARCHAR(50)         NOT NULL,
    country_id              INTEGER             NOT NULL,
    ut                      BOOLEAN,
    CONSTRAINT pk_state_id
        PRIMARY KEY (id),
    CONSTRAINT fk_state_country_id 
        FOREIGN KEY (country_id) 
            REFERENCES country
);

CREATE TABLE city (
    id                      INTEGER             NOT NULL,
    name                    VARCHAR(50)         NOT NULL,
    state_id                INTEGER             NOT NULL,
    latitude                DOUBLE PRECISION    NOT NULL,
    longitude               DOUBLE PRECISION    NOT NULL,
    CONSTRAINT pk_city_id
        PRIMARY KEY (id),
    CONSTRAINT fk_city_state_id
        FOREIGN KEY (state_id)
            REFERENCES state
);

CREATE TABLE pin_code (
    id                      VARCHAR(20)         NOT NULL,
    country_id              INTEGER             NOT NULL,
    pin                     VARCHAR(10)         NOT NULL,
    area_name               VARCHAR(100)        NOT NULL,
    city_id                 INTEGER             NOT NULL,
    CONSTRAINT pk_pin_code_id
        PRIMARY KEY (id),
    CONSTRAINT uk_pin_code_country_id_pin
        UNIQUE (country_id, pin),
    CONSTRAINT fk_pin_code_country_id
        FOREIGN KEY (country_id)
            REFERENCES country,
    CONSTRAINT fk_pin_code_city_id
        FOREIGN KEY (city_id)
            REFERENCES city
);