INSERT INTO consignment (id, sender_id, receiver_id, weight, length, width, height, cost_shipping, source_centre_id, destination_centre_id, otp)
VALUES ('5bdeb2db-d2c5-419b-8d48-1c1616cb5853', 100004, 100002, 0.2, 15, 10, 10, 220, 3, 2, '789464');
INSERT INTO consignment (id, sender_id, receiver_id, weight, length, width, height, cost_shipping, cost_insurance, source_centre_id, destination_centre_id, otp)
VALUES ('65a964eb-eed4-4a8d-b967-0e963d91a3aa', 100004, 100003, 3.6, 30, 20, 15, 970, 620, 3, 2, '521079');
INSERT INTO consignment (id, sender_id, receiver_id, weight, length, width, height, cost_shipping, source_centre_id, destination_centre_id, otp)
VALUES ('cfc44ef8-8158-470d-b1a7-86e02d2b0731', 100006, 100005, 107.3, 55, 40, 15, 29330, 4, 5, '152619');


INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id)
VALUES (1, 'COLLECTED', CURRENT_TIMESTAMP()-4, '5bdeb2db-d2c5-419b-8d48-1c1616cb5853', 13, 10);
INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id)
VALUES (2, 'READY_FOR_SHIPPING', CURRENT_TIMESTAMP()-4, '5bdeb2db-d2c5-419b-8d48-1c1616cb5853', 13, 10);
INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id, vehicle_id)
VALUES (3, 'IN_TRANSIT', CURRENT_TIMESTAMP()-4, '5bdeb2db-d2c5-419b-8d48-1c1616cb5853', 13, 10, 1);
INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id, vehicle_id)
VALUES (4, 'IN_TRANSIT', CURRENT_TIMESTAMP()-3, '5bdeb2db-d2c5-419b-8d48-1c1616cb5853', 101, 3, 2);
INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id, vehicle_id)
VALUES (5, 'IN_TRANSIT', CURRENT_TIMESTAMP()-2, '5bdeb2db-d2c5-419b-8d48-1c1616cb5853', 6017, 7, 3);
INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id)
VALUES (6, 'ARRIVED', CURRENT_TIMESTAMP()-1, '5bdeb2db-d2c5-419b-8d48-1c1616cb5853', 6, 7);
INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id)
VALUES (7, 'READY_FOR_DELIVERY', CURRENT_TIMESTAMP()-1, '5bdeb2db-d2c5-419b-8d48-1c1616cb5853', 6, 8);
INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id)
VALUES (8, 'OUT_FOR_DELIVERY', CURRENT_TIMESTAMP()-1, '5bdeb2db-d2c5-419b-8d48-1c1616cb5853', 6, 8);
INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id)
VALUES (9, 'DELIVERY_ATTEMPTED', CURRENT_TIMESTAMP()-1, '5bdeb2db-d2c5-419b-8d48-1c1616cb5853', 6, 8);
INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id)
VALUES (10, 'OUT_FOR_DELIVERY', CURRENT_TIMESTAMP(), '5bdeb2db-d2c5-419b-8d48-1c1616cb5853', 6, 8);
INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id)
VALUES (11, 'DELIVERED', CURRENT_TIMESTAMP(), '5bdeb2db-d2c5-419b-8d48-1c1616cb5853', 6, 8);

INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id)
VALUES (12, 'COLLECTED', CURRENT_TIMESTAMP()-3, '65a964eb-eed4-4a8d-b967-0e963d91a3aa', 13, 10);
INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id)
VALUES (13, 'READY_FOR_SHIPPING', CURRENT_TIMESTAMP()-3, '65a964eb-eed4-4a8d-b967-0e963d91a3aa', 13, 10);
INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id, vehicle_id)
VALUES (14, 'IN_TRANSIT', CURRENT_TIMESTAMP()-2, '65a964eb-eed4-4a8d-b967-0e963d91a3aa', 13, 10, 1);
INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id, vehicle_id)
VALUES (15, 'IN_TRANSIT', CURRENT_TIMESTAMP()-2, '65a964eb-eed4-4a8d-b967-0e963d91a3aa', 101, 10, 2);
INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id, vehicle_id)
VALUES (16, 'IN_TRANSIT', CURRENT_TIMESTAMP()-1, '65a964eb-eed4-4a8d-b967-0e963d91a3aa', 6017, 7, 3);
INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id)
VALUES (17, 'ARRIVED', CURRENT_TIMESTAMP(), '65a964eb-eed4-4a8d-b967-0e963d91a3aa', 6, 7);

INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id)
VALUES (18, 'COLLECTED', CURRENT_TIMESTAMP()-2, 'cfc44ef8-8158-470d-b1a7-86e02d2b0731', 11, 12);
INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id)
VALUES (19, 'READY_FOR_SHIPPING', CURRENT_TIMESTAMP()-1, 'cfc44ef8-8158-470d-b1a7-86e02d2b0731', 11, 12);
INSERT INTO consignment_status (id, status, timestamp, consignment_id, city_id, employee_id, vehicle_id)
VALUES (20, 'IN_TRANSIT', CURRENT_TIMESTAMP(), 'cfc44ef8-8158-470d-b1a7-86e02d2b0731', 11, 12, 4);
