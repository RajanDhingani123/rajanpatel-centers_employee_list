CREATE VIEW location_info
AS
    SELECT pc.id, pc.pin, pc.area_name area,
        c.id city_id, c.name city, s.name state, country.name country
    FROM pin_code pc
    JOIN city c
        ON c.id = pc.city_id
    JOIN state s
        ON s.id = c.state_id
    JOIN country
        ON country.id = s.country_id;

CREATE VIEW courier_centre_info
AS
    SELECT cc.*, li.pin, li.city_id, li.city, li.state, li.country
    FROM courier_centre cc
    JOIN location_info li
        ON li.id = cc.pin_code_id;

CREATE VIEW employee_info
AS
    SELECT au.*, e.designation, e.date_of_joining,
    cc.name centre_name, li.city_id centre_city_id, li.city centre_city, li.state centre_state, li.country centre_country
    FROM app_user au
    JOIN employee e
        ON au.id = e.id
    LEFT JOIN courier_centre cc
        ON cc.id = e.centre_id
    LEFT JOIN location_info li
        ON li.id = cc.pin_code_id;

CREATE VIEW customer_info
AS
    SELECT au.*, li.pin, li.city_id, li.city, li.state, li.country
    FROM app_user au
    LEFT JOIN employee e
        ON au.id = e.id
    LEFT JOIN location_info li
        ON li.id = au.pin_code_id
    WHERE e.id IS NULL;

CREATE VIEW consignment_status_info
AS
    SELECT cs.*, c.name city, s.name state, country.name country,
        v.type vehicle_type, v.vehicle_number
    FROM consignment_status cs
    JOIN city c
        ON c.id = cs.city_id
    JOIN state s
        ON s.id = c.state_id
    JOIN country
        ON country.id = s.country_id
    LEFT JOIN vehicle v
        ON v.id = cs.vehicle_id;

CREATE VIEW consignment_status_latest
AS
    SELECT cs.*
    FROM consignment_status cs
    JOIN (
        SELECT consignment_id, MAX(id) AS id
        FROM consignment_status
        GROUP BY consignment_id
    ) csl
        ON csl.id = cs.id;

CREATE VIEW consignment_info
AS
    SELECT c.id, c.weight, c.length, c.width, c.height, c.cost_shipping, c.cost_insurance, c.rating,
        sender.email sender_email, sender.phone sender_phone, CONCAT(sender.first_name, ' ', sender.last_name) sender_name,
        receiver.email receiver_email, receiver.phone receiver_phone, CONCAT(receiver.first_name, ' ', receiver.last_name) receiver_name, receiver.address_line1 receiver_address_line1, receiver.address_line2 receiver_address_line2, receiver.latitude receiver_latitude, receiver.longitude receiver_longitude,
        li.pin receiver_pin, li.area receiver_area, li.city receiver_city, li.state receiver_state, li.country receiver_country,
        csl.status, csl.timestamp,
        ei.id employee_id, ei.email employee_email, ei.phone employee_phone, CONCAT(ei.first_name, ' ', ei.last_name) employee_name, ei.designation employee_designation, ei.centre_name employee_centre_name
    FROM consignment c
    LEFT JOIN app_user sender
        ON sender.id = c.sender_id
    LEFT JOIN app_user receiver
        ON receiver.id = c.receiver_id
    LEFT JOIN location_info li
        ON li.id = receiver.pin_code_id
    JOIN consignment_status_latest csl
            ON csl.consignment_id = c.id
    LEFT JOIN employee_info ei
        ON ei.id = csl.employee_id;
