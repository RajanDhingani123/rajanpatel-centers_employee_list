CREATE TABLE consignment (
    id                      UUID                NOT NULL,
    sender_id               INTEGER             NOT NULL,
    receiver_id             INTEGER             NOT NULL,
    weight                  DOUBLE PRECISION    NOT NULL,
    length                  DOUBLE PRECISION    NOT NULL,
    width                   DOUBLE PRECISION    NOT NULL,
    height                  DOUBLE PRECISION,
    cost_shipping           DOUBLE PRECISION    NOT NULL,
    cost_insurance          DOUBLE PRECISION,
    source_centre_id        INTEGER             NOT NULL,
    destination_centre_id   INTEGER             NOT NULL,
    otp                     VARCHAR(10)         NOT NULL,
    rating                  INTEGER,
    CONSTRAINT pk_consignment_id
        PRIMARY KEY (id),
    CONSTRAINT fk_consignment_sender_id
        FOREIGN KEY (sender_id)
            REFERENCES app_user,
    CONSTRAINT fk_consignment_receiver_id
        FOREIGN KEY (receiver_id)
            REFERENCES app_user,
    CONSTRAINT fk_consignment_source_centre_id
        FOREIGN KEY (source_centre_id)
            REFERENCES courier_centre,
    CONSTRAINT fk_consignment_destination_centre_id
        FOREIGN KEY (destination_centre_id)
            REFERENCES courier_centre
);

CREATE TABLE consignment_status (
    id                      BIGINT              NOT NULL,
    status                  VARCHAR(20)         NOT NULL,
    timestamp               TIMESTAMP           NOT NULL,
    consignment_id          UUID                NOT NULL,
    city_id                 INTEGER             NOT NULL,
    employee_id             INTEGER             NOT NULL,
    vehicle_id              BIGINT,
    CONSTRAINT pk_consignment_status_id
        PRIMARY KEY (id),
    CONSTRAINT fk_consignment_status_consignment_id
        FOREIGN KEY (consignment_id)
            REFERENCES consignment,
    CONSTRAINT fk_consignment_status_city_id
        FOREIGN KEY (city_id)
            REFERENCES city,
    CONSTRAINT fk_consignment_status_employee_id
        FOREIGN KEY (employee_id)
            REFERENCES employee,
    CONSTRAINT fk_consignment_status_vehicle_id
        FOREIGN KEY (vehicle_id)
            REFERENCES vehicle
);
