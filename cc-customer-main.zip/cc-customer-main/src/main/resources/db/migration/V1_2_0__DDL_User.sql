CREATE TABLE app_user (
    id                      INTEGER             NOT NULL,
    email                   VARCHAR(100)        NOT NULL,
    phone                   VARCHAR(20)         NOT NULL,
    title                   VARCHAR(20),
    first_name              VARCHAR(50)         NOT NULL,
    middle_name             VARCHAR(50),
    last_name               VARCHAR(50),
    date_of_birth           DATE,
    gender                  VARCHAR(20),
    address_line1           VARCHAR(100)        NOT NULL,
    address_line2           VARCHAR(100),
    pin_code_id             VARCHAR(20)         NOT NULL,
    latitude                DOUBLE PRECISION,
    longitude               DOUBLE PRECISION,
    CONSTRAINT pk_app_user_id
        PRIMARY KEY (id),
    CONSTRAINT uk_app_user_email
        UNIQUE (email),
    CONSTRAINT fk_app_user_pin_code_id
        FOREIGN KEY (pin_code_id)
            REFERENCES pin_code
);

CREATE TABLE employee (
    id                      INTEGER             NOT NULL,
    designation             VARCHAR(20)         NOT NULL,
    date_of_joining         DATE                NOT NULL,
    centre_id               INTEGER             NOT NULL,
    CONSTRAINT pk_employee_id
        PRIMARY KEY (id),
    CONSTRAINT fk_employee_app_user_id
        FOREIGN KEY (id)
            REFERENCES app_user,
    CONSTRAINT fk_employee_centre_id
        FOREIGN KEY (centre_id)
            REFERENCES courier_centre
);

CREATE TABLE user_credential (
    user_id                 INTEGER             NOT NULL,
    password                VARCHAR(100)        NOT NULL,
    CONSTRAINT pk_user_credential_user_id
        PRIMARY KEY (user_id),
    CONSTRAINT fk_user_credential_user_id
        FOREIGN KEY (user_id)
            REFERENCES app_user
);
