INSERT INTO app_user (id, email, phone, title, first_name, last_name, address_line1, pin_code_id, gender, date_of_birth)
VALUES (1, 'nick.fury@marvel.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MR', 'Nicholas', 'Fury', 'Shield', '1_226012', 'MALE', '1950-07-04');
INSERT INTO employee(id, designation, date_of_joining, centre_id)
VALUES (1, 'ADMIN', '2011-01-12', 1);
INSERT INTO app_user (id, email, phone, title, first_name, last_name, address_line1, pin_code_id, gender, date_of_birth)
VALUES (2, 'dr.strange@marvel.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'DR', 'Stephen', 'Strange', 'Sanctum Sanctorum', '1_171203', 'MALE', '1930-11-30');
INSERT INTO employee(id, designation, date_of_joining, centre_id)
VALUES (2, 'TRANSIT_COORDINATOR', '2011-01-12', 1);
INSERT INTO app_user (id, email, phone, title, first_name, last_name, address_line1, pin_code_id, gender, date_of_birth)
VALUES (3, 'iron.man@marvel.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MR', 'Tony', 'Stark', 'Stark Tower', '1_226012', 'MALE', '1970-05-29');
INSERT INTO employee(id, designation, date_of_joining, centre_id)
VALUES (3, 'DELIVERY_AGENT', '2011-01-12', 1);
INSERT INTO app_user (id, email, phone, title, first_name, last_name, address_line1, pin_code_id, gender, date_of_birth)
VALUES (4, 'black.widow@marvel.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MS', 'Natasha', 'Romanaoff', 'Shield', '1_400042', 'FEMALE', '1984-12-03');
INSERT INTO employee(id, designation, date_of_joining, centre_id)
VALUES (4, 'COLLECTOR_AGENT', '2011-01-12', 1);
INSERT INTO app_user (id, email, phone, title, first_name, last_name, address_line1, pin_code_id, gender, date_of_birth)
VALUES (5, 'hawkeye@marvel.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MR', 'Clint', 'Barton', 'Shield 2', '1_700013', 'MALE', '1970-06-18');
INSERT INTO employee(id, designation, date_of_joining, centre_id)
VALUES (5, 'DELIVERY_AGENT', '2011-01-12', 1);
INSERT INTO app_user (id, email, phone, title, first_name, last_name, address_line1, pin_code_id, gender, date_of_birth)
VALUES (6, 'captain.america@marvel.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MR', 'Steve', 'Rogers', 'Ice Hills', '1_226012', 'MALE', '1920-07-04');
INSERT INTO employee(id, designation, date_of_joining, centre_id)
VALUES (6, 'COLLECTOR_AGENT', '2011-01-12', 1);

INSERT INTO app_user (id, email, phone, title, first_name, last_name, address_line1, pin_code_id, gender, date_of_birth)
VALUES (7, 'hulk@marvel.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MR', 'Bruce', 'Banner', 'Gamma Village', '1_226031', 'MALE', '1969-12-18');
INSERT INTO employee(id, designation, date_of_joining, centre_id)
VALUES (7, 'COLLECTOR_AGENT', '2014-10-27', 2);
INSERT INTO app_user (id, email, phone, title, first_name, last_name, address_line1, pin_code_id, gender)
VALUES (8, 'captain.marvel@marvel.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MS', 'Carol', 'Danvers', 'C-53', '1_695007', 'FEMALE');
INSERT INTO employee(id, designation, date_of_joining, centre_id)
VALUES (8, 'DELIVERY_AGENT', '2014-10-27', 2);

INSERT INTO app_user (id, email, phone, title, first_name, last_name, address_line1, pin_code_id, gender, date_of_birth)
VALUES (9, 'spider.man@marvel.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MR', 'Peter', 'Parker', 'Neighborhood', '1_400020', 'MALE', '2001-08-10');
INSERT INTO employee(id, designation, date_of_joining, centre_id)
VALUES (9, 'DELIVERY_AGENT', '2016-04-04', 3);
INSERT INTO app_user (id, email, phone, title, first_name, last_name, address_line1, pin_code_id, gender, date_of_birth)
VALUES (10, 'scarlet.witch@marvel.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MS', 'Wanda', 'Maximoff', 'Westview', '1_700073', 'FEMALE', '1989-02-10');
INSERT INTO employee(id, designation, date_of_joining, centre_id)
VALUES (10, 'COLLECTOR_AGENT', '2016-04-04', 3);
INSERT INTO app_user (id, email, phone, title, first_name, last_name, address_line1, pin_code_id, gender)
VALUES (11, 'thunder.god@marvel.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MR', 'Thor', 'Odinson', 'Asgard', '1_160005', 'MALE');
INSERT INTO employee(id, designation, date_of_joining, centre_id)
VALUES (11, 'DELIVERY_AGENT', '2016-04-04', 3);

INSERT INTO app_user (id, email, phone, title, first_name, last_name, address_line1, pin_code_id, gender)
VALUES (12, 'ant.man@marvel.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MR', 'Scott', 'Lang', 'Quantum Relm', '1_791111', 'MALE');
INSERT INTO employee(id, designation, date_of_joining, centre_id)
VALUES (12, 'COLLECTOR_AGENT', '2016-06-01', 4);
INSERT INTO app_user (id, email, phone, title, first_name, middle_name, last_name, address_line1, pin_code_id, gender)
VALUES (13, 'wasp@marvel.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MS', 'Janet', 'Van', 'Dyne', 'Quantum Relm 2', '1_302016', 'FEMALE');
INSERT INTO employee(id, designation, date_of_joining, centre_id)
VALUES (13, 'DELIVERY_AGENT', '2016-06-01', 4);

INSERT INTO app_user (id, email, phone, title, first_name, address_line1, pin_code_id, gender, date_of_birth)
VALUES (14, 'black.panther@marvel.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MR', 'T''Challa', 'Wakanda', '1_400094', 'MALE', '1983-09-22');
INSERT INTO employee(id, designation, date_of_joining, centre_id)
VALUES (14, 'COLLECTOR_AGENT', '2021-07-06', 5);
INSERT INTO app_user (id, email, phone, title, first_name, last_name, address_line1, pin_code_id, gender, date_of_birth)
VALUES (15, 'war.machine@marvel.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MR', 'James', 'Rhodes', 'Army Cantonment', '1_247664', 'MALE', '1968-10-06');
INSERT INTO employee(id, designation, date_of_joining, centre_id)
VALUES (15, 'DELIVERY_AGENT', '2021-07-06', 5);


INSERT INTO app_user (id, email, phone, title, first_name, last_name, address_line1, pin_code_id, gender, date_of_birth)
VALUES (100001, 'bat.man@dc.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MR', 'Bruce', 'Wayne', 'Gotham', '1_110005', 'MALE', '1915-04-07');
INSERT INTO app_user (id, email, phone, title, first_name, last_name, address_line1, pin_code_id, gender, date_of_birth)
VALUES (100002, 'super.man@dc.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MR', 'Clark', 'Kent', 'Krypton', '1_226012', 'MALE', '1920-02-29');
INSERT INTO app_user (id, email, phone, title, first_name, address_line1, pin_code_id, gender, date_of_birth)
VALUES (100003, 'wonder.woman@dc.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MS', 'Diana', 'Themyscira', '1_226024', 'FEMALE', '1990-03-22');
INSERT INTO app_user (id, email, phone, title, first_name, last_name, address_line1, pin_code_id, gender, date_of_birth)
VALUES (100004, 'flash@dc.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MR', 'Barry', 'Allen', 'Central', '1_400049', 'MALE', '1989-03-14');
INSERT INTO app_user (id, email, phone, title, first_name, last_name, address_line1, pin_code_id, gender, date_of_birth)
VALUES (100005, 'aquaman@dc.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MR', 'Arthur', 'Curry', 'Atlantis', '1_744211', 'MALE', '1986-01-26');
INSERT INTO app_user (id, email, phone, title, first_name, last_name, address_line1, pin_code_id, gender, date_of_birth)
VALUES (100006, 'shazam@dc.com', TO_CHAR(6000000000+FLOOR(4000000000*RAND())), 'MR', 'Billy', 'Batson', 'Philadelphia', '1_600028', 'MALE', '2003-11-29');


INSERT INTO user_credential (user_id, password) VALUES (1, 'Emp@1234');
INSERT INTO user_credential (user_id, password) VALUES (2, 'Emp@1234');
INSERT INTO user_credential (user_id, password) VALUES (3, 'Emp@1234');
INSERT INTO user_credential (user_id, password) VALUES (4, 'Emp@1234');
INSERT INTO user_credential (user_id, password) VALUES (5, 'Emp@1234');
INSERT INTO user_credential (user_id, password) VALUES (6, 'Emp@1234');
INSERT INTO user_credential (user_id, password) VALUES (7, 'Emp@1234');
INSERT INTO user_credential (user_id, password) VALUES (8, 'Emp@1234');
INSERT INTO user_credential (user_id, password) VALUES (9, 'Emp@1234');
INSERT INTO user_credential (user_id, password) VALUES (10, 'Emp@1234');
INSERT INTO user_credential (user_id, password) VALUES (11, 'Emp@1234');
INSERT INTO user_credential (user_id, password) VALUES (12, 'Emp@1234');
INSERT INTO user_credential (user_id, password) VALUES (13, 'Emp@1234');
INSERT INTO user_credential (user_id, password) VALUES (14, 'Emp@1234');
INSERT INTO user_credential (user_id, password) VALUES (15, 'Emp@1234');

INSERT INTO user_credential (user_id, password) VALUES (100001, 'User@123');
INSERT INTO user_credential (user_id, password) VALUES (100002, 'User@123');
INSERT INTO user_credential (user_id, password) VALUES (100003, 'User@123');
INSERT INTO user_credential (user_id, password) VALUES (100004, 'User@123');
INSERT INTO user_credential (user_id, password) VALUES (100005, 'User@123');
INSERT INTO user_credential (user_id, password) VALUES (100006, 'User@123');
