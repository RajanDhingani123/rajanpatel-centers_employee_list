package com.demo.courier.service;

import com.demo.courier.entity.centre.Centre;
import com.demo.courier.entity.centre.Contact;
import com.demo.courier.entity.location.City;
import com.demo.courier.entity.view.CentreInfo;

import java.util.List;

public interface CentreService {
    List<CentreInfo> fetchCentres();

    Centre fetchCentre(int centreId);

    List<Centre> fetchCentres(City city);

    Centre createCentre(Centre centre);

    Centre updateCentre(Centre centre);

    void deleteCentre(int centreId);

    List<Contact> fetchContacts(int centreId);

    Contact addContact(Contact contact);

    void deleteContact(String phone);



}
