package com.demo.courier.repo.readonly;

import com.demo.courier.entity.view.StatusInfo;

import java.util.List;
import java.util.UUID;

public interface StatusInfoRepository extends ReadOnlyRepository<StatusInfo, Integer> {

    List<StatusInfo> findAllByConsignmentIdOrderByTimestamp(UUID consignmentId);

}
