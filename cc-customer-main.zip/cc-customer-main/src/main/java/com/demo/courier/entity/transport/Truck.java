package com.demo.courier.entity.transport;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@DiscriminatorValue(TransportType.Label.TRUCK)
@Entity
public class Truck extends Vehicle {
}
