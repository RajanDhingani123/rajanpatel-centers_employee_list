package com.demo.courier.security;

import com.demo.courier.entity.user.AppUser;
import com.demo.courier.entity.user.Credential;
import com.demo.courier.entity.user.employee.Employee;
import com.demo.courier.repo.user.CredentialRepository;
import com.demo.courier.repo.user.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AppUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CredentialRepository credentialRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<AppUser> appUser = userRepository.findByEmail(username);
        if (appUser.isEmpty())
            throw new UsernameNotFoundException("Username not found: " + username);
        AppUser user = appUser.get();
        Optional<Credential> credential = credentialRepository.findById(user.getId());
        if (credential.isEmpty())
            throw new UsernameNotFoundException("Credential not found: " + username);
        String role = "ROLE_CUSTOMER";
        final List<SimpleGrantedAuthority> authorities = new ArrayList<>();
        if(user instanceof Employee) {
            final Employee employee = (Employee) user;
            role = "ROLE_EMPLOYEE";
            authorities.add(new SimpleGrantedAuthority(employee.getDesignation().toString()+"_AUTHORITY"));
        }
        authorities.add(new SimpleGrantedAuthority(role));
        return new User(String.valueOf(user.getId()), credential.get().getPass(), authorities);
    }

}
