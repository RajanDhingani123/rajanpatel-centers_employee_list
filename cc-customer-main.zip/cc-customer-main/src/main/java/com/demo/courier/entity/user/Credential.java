package com.demo.courier.entity.user;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter @Setter
@Table(name = "user_credential")
@Entity
public class Credential {

    @Id
    @Column(name = "user_id")
    private Integer userId;

    @Column(name = "password",nullable = false, length = 100)
    private String pass;

    @MapsId
    @OneToOne
    @JoinColumn(name="user_id")
    private AppUser appUser;

}
