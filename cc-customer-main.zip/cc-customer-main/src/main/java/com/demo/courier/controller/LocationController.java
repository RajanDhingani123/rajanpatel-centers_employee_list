package com.demo.courier.controller;

import com.demo.courier.entity.location.City;
import com.demo.courier.entity.location.Country;
import com.demo.courier.entity.location.State;
import com.demo.courier.model.Location;
import com.demo.courier.service.LocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/locations")
@RestController
public class LocationController {

    @Autowired
    private LocationService locationService;

    @GetMapping("/countries")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody List<Country> fetchCountries() {
        return locationService.fetchCountries();
    }

    @GetMapping("/countries/{countryId}/states")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody List<State> fetchStates(@PathVariable int countryId) {
        final Country country = new Country();
        country.setId(countryId);
        return locationService.fetchStates(country);
    }

    @GetMapping("/states/{stateId}/cities")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody List<City> fetchCities(@PathVariable int stateId) {
        final State state = new State();
        state.setId(stateId);
        return locationService.fetchCities(state);
    }

    @GetMapping("/countries/{countryId}/pincodes/{pin}")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody Location fetchLocation(@PathVariable int countryId, @PathVariable String pin) {
        final Country country = new Country();
        country.setId(countryId);
        return locationService.fetchLocation(country, pin);
    }

}
