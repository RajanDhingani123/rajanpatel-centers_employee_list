package com.demo.courier.repo.location;

import com.demo.courier.entity.location.Country;
import com.demo.courier.entity.location.State;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StateRepository extends JpaRepository<State, Integer> {

    List<State> findAllByCountry(Country country);

}
