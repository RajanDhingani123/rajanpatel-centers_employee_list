package com.demo.courier.entity.view;

import lombok.Getter;
import org.hibernate.annotations.Immutable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Getter
@Immutable
@Entity(name = "courier_centre_info")
public class CentreInfo {

    @Id
    private Integer id;

    private String name;

    private Double latitude;

    private Double longitude;

    private String addressLine1;

    private String addressLine2;

    private String pinCodeId;

    private String pin;

    private int cityId;

    private String city;

    private String state;

    private String country;

}
