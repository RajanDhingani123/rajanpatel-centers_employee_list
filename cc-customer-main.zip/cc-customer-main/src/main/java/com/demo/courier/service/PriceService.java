package com.demo.courier.service;

import com.demo.courier.entity.location.City;
import com.demo.courier.model.InsurancePrice;

import java.time.LocalDate;

public interface PriceService {
    Double shippingPrice(City source, City destination, double weight);

    InsurancePrice insurancePrice(Double billedAmount, LocalDate billDate);

}
