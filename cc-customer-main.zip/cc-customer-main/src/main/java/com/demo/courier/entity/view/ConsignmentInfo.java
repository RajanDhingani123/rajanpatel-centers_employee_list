package com.demo.courier.entity.view;

import com.demo.courier.entity.consignment.State;
import com.demo.courier.entity.user.employee.Designation;
import lombok.Getter;
import org.hibernate.annotations.Immutable;

import javax.persistence.*;
import java.time.Instant;
import java.util.UUID;

@Getter
@Immutable
@Entity
public class ConsignmentInfo {

    @Id
    private UUID id;

    private Double weight;

    private Double length;

    private Double width;

    private Double height;

    private Double costShipping;

    private Double costInsurance;

    private Integer rating;

    private String senderName;

    private String senderEmail;

    private String senderPhone;

    private String receiverName;

    private String receiverEmail;

    private String receiverPhone;

    private String receiverAddressLine1;

    private String receiverAddressLine2;

    private Double receiverLatitude;

    private Double receiverLongitude;

    private String receiverPin;

    private String receiverArea;

    private String receiverCity;

    private String receiverState;

    private String receiverCountry;

    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private State state;

    private Instant timestamp;

    private Integer employeeId;

    private String employeeName;

    private String employeeEmail;

    private String employeePhone;

    @Enumerated(EnumType.STRING)
    private Designation employeeDesignation;

    private String employeeCentreName;

}
