package com.demo.courier.controller;

import com.demo.courier.entity.transport.Vehicle;
import com.demo.courier.model.Enum;
import com.demo.courier.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/vehicles")
@RestController
public class VehicleController {

    @Autowired
    private VehicleService vehicleService;

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody List<Vehicle> fetchVehicles() {
        return vehicleService.fetchVehicles();
    }

    @GetMapping("/{vehicleId}")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody Vehicle fetchVehicle(@PathVariable long vehicleId) {
        return vehicleService.fetchVehicle(vehicleId);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public @ResponseBody Vehicle addVehicle(@RequestBody Vehicle vehicle) {
        return vehicleService.addVehicle(vehicle);
    }

    @GetMapping("/types")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody List<Enum> fetchVehicleTypes() {
        return vehicleService.fetchVehicleTypes();
    }

}
