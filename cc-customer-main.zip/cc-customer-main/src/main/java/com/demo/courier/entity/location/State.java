package com.demo.courier.entity.location;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

@Getter @Setter @ToString
@Entity
public class State {

    @Id
    @Column
    private Integer id;

    @Column(nullable = false, length = 50)
    private String name;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "country_id", nullable = false, foreignKey = @ForeignKey(name = "fk_state_country_id"))
    private Country country;

    private Boolean ut;

    @JsonIgnore(value = false)
    @Transient
    private int countryId;

    public int getCountryId() {
        return country.getId();
    }

}
