package com.demo.courier.service;

import com.demo.courier.entity.centre.Centre;
import com.demo.courier.entity.user.AppUser;
import com.demo.courier.entity.user.employee.Employee;
import com.demo.courier.entity.view.CustomerInfo;
import com.demo.courier.entity.view.EmployeeInfo;
import com.demo.courier.model.Enum;

import java.util.List;

public interface UserService {
    List<CustomerInfo> fetchCustomers();

    List<EmployeeInfo> fetchEmployees();

    List<Employee> fetchEmployees(Centre centre);

    AppUser createCustomer(AppUser customer);

    Employee createEmployee(AppUser employee);

    AppUser fetchUser(int id);

    void updateEmployees(List<Employee> employees);

    List<Enum> fetchTitles();

    List<Enum> fetchDesignations();

}
