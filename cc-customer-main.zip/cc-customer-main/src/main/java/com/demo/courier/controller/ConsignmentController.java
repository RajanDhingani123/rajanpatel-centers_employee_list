package com.demo.courier.controller;

import com.demo.courier.entity.consignment.Consignment;
import com.demo.courier.entity.consignment.State;
import com.demo.courier.entity.user.AppUser;
import com.demo.courier.entity.view.ConsignmentInfo;
import com.demo.courier.entity.view.StatusInfo;
import com.demo.courier.model.ConsignmentRequest;
import com.demo.courier.model.Enum;
import com.demo.courier.model.ItemPrice;
import com.demo.courier.service.ConsignmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RequestMapping("/consignments")
@RestController
public class ConsignmentController {

    @Autowired
    private ConsignmentService consignmentService;

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody List<ConsignmentInfo> fetchConsignments() {
        return consignmentService.fetchConsignments();
    }

    @GetMapping("/{consignmentId}")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody ConsignmentInfo fetchConsignment(@PathVariable String consignmentId) {
        return consignmentService.fetchConsignmentInfo(consignmentId);
    }

    @GetMapping("/{consignmentId}/status")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody List<StatusInfo> fetchConsignmentStatus(@PathVariable String consignmentId) {
        return consignmentService.fetchConsignmentStatus(consignmentId);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public @ResponseBody ConsignmentInfo collectConsignment(@RequestBody ConsignmentRequest consignmentRequest) {
        Consignment consignment = new Consignment();
        consignment.setWeight(consignmentRequest.getWeight());
        consignment.setLength(consignmentRequest.getLength());
        consignment.setWidth(consignmentRequest.getWidth());
        consignment.setHeight(consignmentRequest.getHeight());
        consignment.setSender(new AppUser(consignmentRequest.getSenderId()));
        consignment.setReceiver(new AppUser(consignmentRequest.getReceiverId()));
        ItemPrice itemPrice = null;
        if (consignmentRequest.isInsured())
            itemPrice = new ItemPrice(consignmentRequest.getBilledAmount(), consignmentRequest.getBilledDate());
        final UUID id = consignmentService.collectConsignment(consignment, itemPrice).getId();
        return consignmentService.fetchConsignmentInfo(id.toString());
    }

    @PatchMapping("/{consignmentId}/states/{state}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public @ResponseBody void shipConsignment(@PathVariable String consignmentId, @PathVariable State state,
                                              @RequestParam(required = false) Long vehicleId,
                                              @RequestParam(required = false) String otp) {
        if (State.IN_TRANSIT == state && vehicleId != null)
            consignmentService.updateStatus(consignmentId, state, vehicleId);
        else if (State.DELIVERED == state && otp != null)
            consignmentService.updateStatus(consignmentId, state, otp);
        else
            consignmentService.updateStatus(consignmentId, state);
    }

    @GetMapping("/states/{state}")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody List<Enum> fetchStates(@PathVariable State state) {
        return consignmentService.fetchStates(state);
    }

}
