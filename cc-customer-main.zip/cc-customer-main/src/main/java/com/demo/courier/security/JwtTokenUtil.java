package com.demo.courier.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

public class JwtTokenUtil {

    private static String SECRET = "Teleport@Secret";
    private static final long JWT_TOKEN_VALIDITY_PERIOD = 1000 * 60 * 60 * 2;

    private JwtTokenUtil() {}

    public static String generateToken(UserDetails userDetails, Map<String, Object> claims) {
        JwtBuilder builder = Jwts.builder()
                .setClaims(new HashMap<>())
                .setSubject(userDetails.getUsername())
                .setIssuer("Teleport")
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + JWT_TOKEN_VALIDITY_PERIOD))
                .signWith(SignatureAlgorithm.HS512, SECRET);
        if(null != claims)
            claims.forEach(builder::claim);
        return builder.compact();
    }

    private static <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = Jwts.parser()
                .setSigningKey(SECRET)
                .parseClaimsJws(token)
                .getBody();
        return claimsResolver.apply(claims);
    }

    public static String getUsernameFromToken(String token) {
        return getClaimFromToken(token, Claims::getSubject);
    }

}
