package com.demo.courier.service.impl;

import com.demo.courier.entity.location.City;
import com.demo.courier.entity.location.Country;
import com.demo.courier.entity.location.PinCode;
import com.demo.courier.entity.location.State;
import com.demo.courier.exception.NotFoundException;
import com.demo.courier.model.Location;
import com.demo.courier.repo.location.CityRepository;
import com.demo.courier.repo.location.CountryRepository;
import com.demo.courier.repo.location.PinCodeRepository;
import com.demo.courier.repo.location.StateRepository;
import com.demo.courier.service.LocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LocationServiceImpl implements LocationService {

    @Autowired
    private CountryRepository countryRepository;

    @Autowired
    private StateRepository stateRepository;

    @Autowired
    private CityRepository cityRepository;

    @Autowired
    private PinCodeRepository pinCodeRepository;

    @Override
    public List<Country> fetchCountries() {
        return countryRepository.findAll();
    }

    @Override
    public List<State> fetchStates(Country country) {
        return stateRepository.findAllByCountry(country);
    }

    @Override
    public List<City> fetchCities(State state) {
        return cityRepository.findAllByState(state);
    }

    @Override
    public Location fetchLocation(Country country, String pin) throws NotFoundException {
        Optional<PinCode> optionalPinCode = pinCodeRepository.findByCountryAndPin(country, pin);
        if (optionalPinCode.isEmpty())
            throw new NotFoundException("pincode/country=%d&pin=%s", country.getId(), pin);
        final Location location = new Location();
        PinCode pinCode = optionalPinCode.get();
        location.setId(pinCode.getId());
        location.setArea(pinCode.getAreaName());
        location.setCity(pinCode.getCity());
        location.setState(pinCode.getCity().getState());
        location.setCountry(pinCode.getCountry());
        return location;
    }

    @Override
    public List<PinCode> fetchPinCodes(City city) {
        return pinCodeRepository.findAllByCity(city);
    }

}
