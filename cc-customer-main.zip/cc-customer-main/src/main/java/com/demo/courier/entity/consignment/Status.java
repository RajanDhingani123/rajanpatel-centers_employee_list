package com.demo.courier.entity.consignment;

import com.demo.courier.entity.location.City;
import com.demo.courier.entity.transport.Vehicle;
import com.demo.courier.entity.user.employee.Employee;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;

@Getter @Setter
@Table(name = "consignment_status")
@Entity
public class Status {

    @Id
    @SequenceGenerator(name = "sg_consignment_status_id", sequenceName = "sq_consignment_status_id", initialValue = 100, allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sg_consignment_status_id")
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private State state;

    @Column(nullable = false)
    private Instant timestamp;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "consignment_id", nullable = false, foreignKey = @ForeignKey(name = "fk_consignment_status_consignment_id"))
    private Consignment consignment;

    @ManyToOne
    @JoinColumn(name = "city_id", nullable = false, foreignKey = @ForeignKey(name = "fk_consignment_status_city_id"))
    private City city;

    @ManyToOne
    @JoinColumn(name = "employee_id", nullable = false, foreignKey = @ForeignKey(name = "fk_consignment_status_employee_id"))
    private Employee employee;

    @OneToOne
    @JoinColumn(name = "vehicle_id", foreignKey = @ForeignKey(name = "fk_consignment_status_vehicle_id"))
    private Vehicle vehicle;

}
