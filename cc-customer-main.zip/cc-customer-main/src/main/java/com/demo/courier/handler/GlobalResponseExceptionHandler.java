package com.demo.courier.handler;

import com.demo.courier.exception.InvalidRequestException;
import com.demo.courier.exception.NotAllowedException;
import com.demo.courier.exception.NotFoundException;
import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class GlobalResponseExceptionHandler extends ResponseEntityExceptionHandler {

    @Getter
    private class APIError {

        String message;

        APIError(String message) {
            this.message = message;
        }

    }

    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<APIError> handleNotFoundException(NotFoundException e) {
        APIError error = new APIError(e.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(error);
    }

    @ExceptionHandler(InvalidRequestException.class)
    public ResponseEntity<APIError> handleInvalidRequestException(InvalidRequestException e) {
        APIError error = new APIError(e.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(error);
    }

    @ExceptionHandler(NotAllowedException.class)
    public ResponseEntity<APIError> handleNotAllowedException(NotAllowedException e) {
        APIError error = new APIError(e.getMessage());
        return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
                .body(error);
    }

    @ExceptionHandler(AuthenticationException.class)
    public ResponseEntity<APIError> handleAuthenticationException(AuthenticationException e) {
        APIError error = new APIError(e.getMessage());
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(error);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<APIError> handleException(Exception e) {
        e.printStackTrace();
        APIError error = new APIError(e.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(error);
    }

}
