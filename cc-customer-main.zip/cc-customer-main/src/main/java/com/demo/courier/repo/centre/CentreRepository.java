package com.demo.courier.repo.centre;

import com.demo.courier.entity.centre.Centre;
import com.demo.courier.entity.location.PinCode;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CentreRepository extends JpaRepository<Centre, Integer> {

    List<Centre> findAllByPinCodeInOrderById(List<PinCode> pinCodes);

}
