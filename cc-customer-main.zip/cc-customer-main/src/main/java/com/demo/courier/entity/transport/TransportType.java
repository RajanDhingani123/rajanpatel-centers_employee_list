package com.demo.courier.entity.transport;

public enum TransportType {

    AIRPLANE(Label.AIRPLANE),
    TRAIN(Label.TRAIN),
    TRUCK(Label.TRUCK),
    SHIP(Label.SHIP);

    public class Label {
        public static final String AIRPLANE = "AIRPLANE";
        public static final String TRAIN = "TRAIN";
        public static final String TRUCK = "TRUCK";
        public static final String SHIP = "SHIP";
    }

    private final String label;

    private TransportType(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }


}
