package com.demo.courier.repo.readonly;

import com.demo.courier.entity.view.ConsignmentInfo;

import java.util.UUID;

public interface ConsignmentInfoRepository extends ReadOnlyRepository<ConsignmentInfo, UUID> {

}
