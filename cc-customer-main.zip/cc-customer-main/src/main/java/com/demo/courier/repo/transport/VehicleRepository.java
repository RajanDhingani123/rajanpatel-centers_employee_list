package com.demo.courier.repo.transport;

import com.demo.courier.entity.transport.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VehicleRepository extends JpaRepository<Vehicle, Long> {

}
