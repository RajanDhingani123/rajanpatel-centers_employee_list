package com.demo.courier.controller;

import com.demo.courier.entity.user.AppUser;
import com.demo.courier.entity.user.employee.Employee;
import com.demo.courier.entity.view.CustomerInfo;
import com.demo.courier.entity.view.EmployeeInfo;
import com.demo.courier.model.Enum;
import com.demo.courier.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/users")
@RestController
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/employees")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody List<EmployeeInfo> fetchEmployees() {
        return userService.fetchEmployees();
    }

    @GetMapping("/customers")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody List<CustomerInfo> fetchCustomers() {
        return userService.fetchCustomers();
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public @ResponseBody AppUser createCustomer(@RequestBody AppUser customer) {
        customer.setId(null);
        return userService.createCustomer(customer);
    }

    @PostMapping("/employees")
    @ResponseStatus(HttpStatus.CREATED)
    public @ResponseBody Employee createEmployee(@RequestBody Employee employee) {
        employee.setId(null);
        return userService.createEmployee(employee);
    }

    @GetMapping("/titles")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody List<Enum> fetchTitles() {
        return userService.fetchTitles();
    }

    @GetMapping("/employees/designations")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody List<Enum> fetchDesignations() {
        return userService.fetchDesignations();
    }

}
