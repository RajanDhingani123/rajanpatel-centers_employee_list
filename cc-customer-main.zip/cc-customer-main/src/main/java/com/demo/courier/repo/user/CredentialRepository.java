package com.demo.courier.repo.user;

import com.demo.courier.entity.user.Credential;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CredentialRepository extends JpaRepository<Credential, Integer> {

}
