package com.demo.courier.entity.transport;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@DiscriminatorValue(TransportType.Label.AIRPLANE)
@Entity
public class Airplane extends Vehicle {
}
