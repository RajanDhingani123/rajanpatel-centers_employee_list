package com.demo.courier.repo.location;

import com.demo.courier.entity.location.City;
import com.demo.courier.entity.location.Country;
import com.demo.courier.entity.location.PinCode;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PinCodeRepository extends JpaRepository<PinCode, String> {

    Optional<PinCode> findByCountryAndPin(Country country, String pin);

    List<PinCode> findAllByCity(City city);

}
