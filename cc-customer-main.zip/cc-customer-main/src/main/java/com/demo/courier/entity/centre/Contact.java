package com.demo.courier.entity.centre;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter @Setter
@Table(name = "centre_contact")
@Entity
public class Contact {

    @Id
    @Column(nullable = false, length = 20)
    private String phone;

    @Column(nullable = false, length = 50)
    private String department;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "centre_id", nullable = false, foreignKey = @ForeignKey(name = "fk_centre_contact_centre_id"))
    private Centre centre;

}
