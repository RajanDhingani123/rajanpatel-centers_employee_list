package com.demo.courier.entity.user;

public enum Gender {
    FEMALE,
    MALE
}
