package com.demo.courier.entity.user.employee;

public enum Designation {

    ADMIN(Label.ADMIN),
    COLLECTOR_AGENT(Label.COLLECTOR_AGENT),
    DELIVERY_AGENT(Label.DELIVERY_AGENT),
    TRANSIT_COORDINATOR(Label.TRANSIT_COORDINATOR);

    public class Label {
        public static final String ADMIN = "Administrator";
        public static final String COLLECTOR_AGENT = "Collector Agent";
        public static final String DELIVERY_AGENT = "Delivery Agent";
        public static final String TRANSIT_COORDINATOR = "Transit Coordinator";
    }

    private final String label;

    private Designation(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }

}
