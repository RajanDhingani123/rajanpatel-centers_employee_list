package com.demo.courier.entity.user.employee;

import com.demo.courier.entity.centre.Centre;
import com.demo.courier.entity.user.AppUser;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDate;

@NoArgsConstructor
@Getter @Setter @ToString
@Entity
public class Employee extends AppUser {

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Designation designation;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(nullable = false)
    private LocalDate dateOfJoining;

    @ManyToOne
    @JoinColumn(name = "centre_id", nullable = false, foreignKey = @ForeignKey(name = "fk_employee_centre_id"))
    private Centre centre;

    public Employee(int id) {
        super(id);
    }

}
