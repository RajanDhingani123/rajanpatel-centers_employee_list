package com.demo.courier.repo.readonly;

import com.demo.courier.entity.view.EmployeeInfo;

public interface EmployeeInfoRepository extends ReadOnlyRepository<EmployeeInfo, Integer> {

}
