package com.demo.courier.service.impl;

import com.demo.courier.entity.centre.Centre;
import com.demo.courier.entity.centre.Contact;
import com.demo.courier.entity.location.City;
import com.demo.courier.entity.location.PinCode;
import com.demo.courier.entity.user.employee.Employee;
import com.demo.courier.entity.view.CentreInfo;
import com.demo.courier.exception.NotFoundException;
import com.demo.courier.repo.centre.CentreRepository;
import com.demo.courier.repo.centre.ContactRepository;
import com.demo.courier.repo.readonly.CentreInfoRepository;
import com.demo.courier.service.CentreService;
import com.demo.courier.service.LocationService;
import com.demo.courier.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class CentreServiceImpl implements CentreService {

    @Autowired
    private CentreRepository centreRepository;

    @Autowired
    private CentreInfoRepository centreInfoRepository;

    @Autowired
    private ContactRepository contactRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private LocationService locationService;

    @Override
    public List<CentreInfo> fetchCentres() {
        return centreInfoRepository.findAll();
    }

    @Override
    public Centre fetchCentre(int centreId) {
        Optional<Centre> centre = centreRepository.findById(centreId);
        if (centre.isEmpty())
            throw new NotFoundException("centre=%d", centreId);
        return centre.get();
    }

    @Override
    public List<Centre> fetchCentres(City city) {
        List<PinCode> pinCodes = locationService.fetchPinCodes(city);
        return centreRepository.findAllByPinCodeInOrderById(pinCodes);
    }

    @Override
    public Centre createCentre(Centre centre) {
        return centreRepository.save(centre);
    }

    @Override
    public Centre updateCentre(Centre centre) {
        fetchCentre(centre.getId());
        return centreRepository.save(centre);
    }

    @Transactional
    @Override
    public void deleteCentre(int centreId) {
        Centre centre = fetchCentre(centreId);
        List<Employee> employees = userService.fetchEmployees(centre);
        centre = new Centre();
        centre.setId(0);
        for (Employee employee : employees)
            employee.setCentre(centre);
        userService.updateEmployees(employees);
        centreRepository.deleteById(centreId);
    }

    @Override
    public List<Contact> fetchContacts(int centreId) {
        final Centre centre = fetchCentre(centreId);
        return contactRepository.findAllByCentre(centre);
    }

    @Override
    public Contact addContact(Contact contact) {
        fetchCentre(contact.getCentre().getId());
        return contactRepository.save(contact);
    }

    @Override
    public void deleteContact(String phone) {
        final boolean exist = contactRepository.existsById(phone);
        if (!exist)
            throw new NotFoundException("phone=%s", phone);
        contactRepository.deleteById(phone);
    }

}
