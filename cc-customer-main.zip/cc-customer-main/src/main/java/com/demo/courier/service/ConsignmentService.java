package com.demo.courier.service;

import com.demo.courier.entity.consignment.Consignment;
import com.demo.courier.entity.consignment.State;
import com.demo.courier.entity.view.ConsignmentInfo;
import com.demo.courier.entity.view.StatusInfo;
import com.demo.courier.model.Enum;
import com.demo.courier.model.ItemPrice;

import java.util.List;

public interface ConsignmentService {

    List<ConsignmentInfo> fetchConsignments();

    ConsignmentInfo fetchConsignmentInfo(String consignmentId);

    Consignment fetchConsignment(String consignmentId);

    List<StatusInfo> fetchConsignmentStatus(String consignmentId);

    Consignment collectConsignment(Consignment consignment, ItemPrice itemPrice);

    void updateStatus(String consignmentId, State state);

    void updateStatus(String consignmentId, State state, long vehicleId);

    void updateStatus(String consignmentId, State state, String otp);

    List<Enum> fetchStates(State state);

}
