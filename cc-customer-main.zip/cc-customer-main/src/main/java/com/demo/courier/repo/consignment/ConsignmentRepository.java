package com.demo.courier.repo.consignment;

import com.demo.courier.entity.consignment.Consignment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface ConsignmentRepository extends JpaRepository<Consignment, UUID> {

}
