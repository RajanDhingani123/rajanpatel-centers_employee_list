package com.demo.courier.entity.consignment;

import com.demo.courier.entity.centre.Centre;
import com.demo.courier.entity.user.AppUser;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.List;
import java.util.UUID;

@Getter @Setter @ToString
@Entity
public class Consignment {

    @Id
    @GeneratedValue
    private UUID id;

    @Column(nullable = false)
    private Double weight;

    @Column(nullable = false)
    private Double length;

    @Column(nullable = false)
    private Double width;

    @Column
    private Double height;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "sender_id", nullable = false, foreignKey = @ForeignKey(name = "fk_consignment_sender_id"))
    private AppUser sender;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "receiver_id", nullable = false, foreignKey = @ForeignKey(name = "fk_consignment_receiver_id"))
    private AppUser receiver;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "source_centre_id", nullable = false, foreignKey = @ForeignKey(name = "fk_consignment_source_centre_id"))
    private Centre centreSource;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "destination_centre_id", nullable = false, foreignKey = @ForeignKey(name = "fk_consignment_destination_centre_id"))
    private Centre centreDestination;

    @Column(nullable = false)
    private Double costShipping;

    @Column
    private Double costInsurance;

    @JsonIgnore
    @Column(nullable = false, length = 10)
    private String otp;

    @JsonIgnore
    @OneToMany(mappedBy = "consignment")
    private List<Status> status;

    @Column
    private Integer rating;

}
