package com.demo.courier.repo.location;

import com.demo.courier.entity.location.City;
import com.demo.courier.entity.location.State;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CityRepository extends JpaRepository<City, Integer> {

    List<City> findAllByState(State state);

}
