package com.demo.courier.service;

import com.demo.courier.entity.location.City;
import com.demo.courier.entity.location.Country;
import com.demo.courier.entity.location.PinCode;
import com.demo.courier.entity.location.State;
import com.demo.courier.model.Location;

import java.util.List;

public interface LocationService
{
    List<Country> fetchCountries();

    List<State> fetchStates(Country country);

    List<City> fetchCities(State state);

    Location fetchLocation(Country country, String pin);

    List<PinCode> fetchPinCodes(City city);

}
