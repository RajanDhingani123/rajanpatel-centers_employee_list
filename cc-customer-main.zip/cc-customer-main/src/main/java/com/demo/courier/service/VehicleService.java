package com.demo.courier.service;

import com.demo.courier.entity.transport.Vehicle;
import com.demo.courier.model.Enum;

import java.util.List;

public interface VehicleService {

    List<Vehicle> fetchVehicles();

    Vehicle fetchVehicle(long vehicleId);

    Vehicle addVehicle(Vehicle vehicle);

    List<Enum> fetchVehicleTypes();

}
