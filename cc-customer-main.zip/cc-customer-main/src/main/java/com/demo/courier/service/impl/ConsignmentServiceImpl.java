package com.demo.courier.service.impl;

import com.demo.courier.entity.centre.Centre;
import com.demo.courier.entity.consignment.Consignment;
import com.demo.courier.entity.consignment.State;
import com.demo.courier.entity.consignment.Status;
import com.demo.courier.entity.location.City;
import com.demo.courier.entity.transport.Vehicle;
import com.demo.courier.entity.user.AppUser;
import com.demo.courier.entity.user.employee.Employee;
import com.demo.courier.entity.view.ConsignmentInfo;
import com.demo.courier.entity.view.StatusInfo;
import com.demo.courier.exception.InvalidRequestException;
import com.demo.courier.exception.NotAllowedException;
import com.demo.courier.exception.NotFoundException;
import com.demo.courier.model.Enum;
import com.demo.courier.model.InsurancePrice;
import com.demo.courier.model.ItemPrice;
import com.demo.courier.repo.consignment.ConsignmentRepository;
import com.demo.courier.repo.consignment.StatusRepository;
import com.demo.courier.repo.readonly.ConsignmentInfoRepository;
import com.demo.courier.repo.readonly.StatusInfoRepository;
import com.demo.courier.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class ConsignmentServiceImpl implements ConsignmentService {

    private static final Random random = new Random();

    @Autowired
    private ConsignmentRepository consignmentRepository;

    @Autowired
    private ConsignmentInfoRepository consignmentInfoRepository;

    @Autowired
    private StatusRepository statusRepository;

    @Autowired
    private StatusInfoRepository statusInfoRepository;

    @Autowired
    private PriceService priceService;

    @Autowired
    private UserService userService;

    @Autowired
    private CentreService centreService;

    @Autowired
    private VehicleService vehicleService;

    @Override
    public List<ConsignmentInfo> fetchConsignments() {
        return consignmentInfoRepository.findAll();
    }

    @Override
    public ConsignmentInfo fetchConsignmentInfo(String consignmentId) {
        Optional<ConsignmentInfo> consignmentInfo = consignmentInfoRepository.findById(UUID.fromString(consignmentId));
        if (consignmentInfo.isEmpty())
            throw new NotFoundException("consignment=%s", consignmentId);
        return consignmentInfo.get();
    }

    @Override
    public Consignment fetchConsignment(String consignmentId) {
        Optional<Consignment> consignment = consignmentRepository.findById(UUID.fromString(consignmentId));
        if (consignment.isEmpty())
            throw new NotFoundException("consignment=%s", consignmentId);
        return consignment.get();
    }

    @Override
    public List<StatusInfo> fetchConsignmentStatus(String consignmentId) {
        try {
            final UUID id = UUID.fromString(consignmentId);
            return statusInfoRepository.findAllByConsignmentIdOrderByTimestamp(id);
        } catch (IllegalArgumentException e) {
            throw new NotFoundException("consignment=%s", consignmentId);
        }
    }

    @Transactional
    @Override
    public Consignment collectConsignment(Consignment consignment, ItemPrice itemPrice) {
        final AppUser receiver = userService.fetchUser(consignment.getReceiver().getId());
        final City destinationCity = receiver.getPinCode().getCity();
        List<Centre> centres = centreService.fetchCentres(destinationCity);
        if (centres.isEmpty())
            throw new NotFoundException("centre?city=%d", destinationCity.getId());
        final Centre centre = centres.get(0);
        consignment.setCentreDestination(centre);

        final String userId = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        final Employee collector = (Employee) userService.fetchUser(Integer.valueOf(userId));
        consignment.setCentreSource(collector.getCentre());

        final double shippingPrice = priceService.shippingPrice(collector.getCentre().getPinCode().getCity(), receiver.getPinCode().getCity(), consignment.getWeight());
        consignment.setCostShipping(shippingPrice);
        if (null != itemPrice) {
            final InsurancePrice insurancePrice = priceService.insurancePrice(itemPrice.getBilledAmount(), itemPrice.getBilledDate());
            consignment.setCostInsurance(insurancePrice.getInsurancePrice());
        }
        consignment.setOtp(generateOTP());
        consignment = consignmentRepository.save(consignment);

        final Status status = new Status();
        status.setConsignment(consignment);
        status.setState(State.COLLECTED);
        status.setCity(collector.getCentre().getPinCode().getCity());
        status.setEmployee(collector);
        status.setTimestamp(Instant.now());
        statusRepository.save(status);

        return consignment;
    }

    private String generateOTP() {
        final int digit = 6;
        final int min = (int) Math.pow(10, digit - 1);
        final int otp = min + random.nextInt(9 * min);
        return String.valueOf(otp);
    }

    @Override
    public void updateStatus(String consignmentId, State state) {
        if (State.IN_TRANSIT == state)
            throw new InvalidRequestException("missing vehicleId");
        if (State.DELIVERED == state)
            throw new InvalidRequestException("missing otp");
        final Consignment consignment = fetchConsignment(consignmentId);
        final Status status = prepareStatus(consignment, state);
        statusRepository.save(status);
    }

    private Status prepareStatus(Consignment consignment, State state) {
        final Status currentStatus = statusRepository.findTopByConsignmentOrderByTimestampDesc(consignment);
        if (!State.next(currentStatus.getState()).contains(state))
            throw new NotAllowedException("state=%s", state.name());
        if(State.READY_FOR_SHIPPING == state &&
                currentStatus.getCity().getId() == consignment.getReceiver().getPinCode().getCity().getId())
            throw new InvalidRequestException("consignment.city=%s", currentStatus.getCity().getId());
        if (State.READY_FOR_DELIVERY == state &&
                currentStatus.getCity().getId() != consignment.getReceiver().getPinCode().getCity().getId())
            throw new NotAllowedException("consignment.city=%s", currentStatus.getCity().getId());

        final String userId = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        final Employee employee = (Employee) userService.fetchUser(Integer.valueOf(userId));
        Status newStatus = new Status();
        newStatus.setConsignment(consignment);
        newStatus.setState(state);
        newStatus.setEmployee(employee);
        newStatus.setCity(employee.getCentre().getPinCode().getCity());
        newStatus.setTimestamp(Instant.now());

        return newStatus;
    }

    @Override
    public void updateStatus(String consignmentId, State state, long vehicleId) {
        final Consignment consignment = fetchConsignment(consignmentId);
        final Status status = prepareStatus(consignment, state);
        final Vehicle vehicle = vehicleService.fetchVehicle(vehicleId);

        if (State.IN_TRANSIT == state &&
                vehicle.getSource().getId() == consignment.getReceiver().getPinCode().getCity().getId())
            throw new NotAllowedException("consignment.city=%s", vehicle.getSource().getId());

        status.setCity(vehicle.getSource());
        status.setVehicle(vehicle);
        statusRepository.save(status);
    }

    @Override
    public void updateStatus(String consignmentId, State state, String otp) {
        final Consignment consignment = fetchConsignment(consignmentId);
        if (!consignment.getOtp().equals(otp))
            throw new NotAllowedException("incorrect otp=%s", otp);
        final Status status = prepareStatus(consignment, state);
        statusRepository.save(status);
    }

    @Override
    public List<Enum> fetchStates(State current) {
        return State.next(current).stream()
                .map(state -> new Enum(state.name(), state.label()))
                .collect(Collectors.toList());
    }

}
