package com.demo.courier.model;

import com.demo.courier.entity.location.City;
import com.demo.courier.entity.location.Country;
import com.demo.courier.entity.location.State;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Location {

    private String id;
    private String area;
    private City city;
    private State state;
    private Country country;

}
