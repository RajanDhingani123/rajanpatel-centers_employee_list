package com.demo.courier.entity.transport;

import com.demo.courier.entity.location.City;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Getter @Setter @ToString
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME,  property = "type", visible = true)
@JsonSubTypes({
        @JsonSubTypes.Type(value = Airplane.class, name = TransportType.Label.AIRPLANE),
        @JsonSubTypes.Type(value = Train.class, name = TransportType.Label.TRAIN),
        @JsonSubTypes.Type(value = Truck.class, name = TransportType.Label.TRUCK),
        @JsonSubTypes.Type(value = Ship.class, name = TransportType.Label.SHIP)
})
@DiscriminatorColumn(name = "type", length = 20, discriminatorType = DiscriminatorType.STRING)
@Inheritance
@Table(uniqueConstraints = @UniqueConstraint(columnNames = {"vehicle_number", "date"}, name = "uk_vehicle_vehicle_number_date"))
@Entity
public abstract class Vehicle {

    @Id
    @SequenceGenerator(name = "sg_vehicle_id", sequenceName = "sq_vehicle_id", initialValue = 10, allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sg_vehicle_id")
    private Long id;

    @Column(name = "vehicle_number", nullable = false, length = 20)
    private String vehicleNumber;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(nullable = false)
    private LocalDate date;

    @ManyToOne
    @JoinColumn(name = "source_city_id", nullable = false, foreignKey = @ForeignKey(name = "fk_vehicle_source_city_id"))
    private City source;

    @ManyToMany
    @JoinTable(
            name = "vehicle_destination",
            joinColumns = @JoinColumn(name = "vehicle_id", nullable = false, foreignKey = @ForeignKey(name = "fk_vehicle_destination_vehicle_id")),
            inverseJoinColumns = @JoinColumn(name = "city_id", nullable = false, foreignKey = @ForeignKey(name = "fk_vehicle_destination_city_id"))
    )
    private List<City> destinations;

}
