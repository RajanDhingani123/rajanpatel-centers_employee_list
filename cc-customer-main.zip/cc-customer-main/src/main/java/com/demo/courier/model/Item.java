package com.demo.courier.model;

import com.demo.courier.entity.location.City;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Item {

    private City source;
    private City destination;
    private double weight;

}
