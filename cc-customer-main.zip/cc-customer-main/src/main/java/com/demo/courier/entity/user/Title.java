package com.demo.courier.entity.user;

public enum Title {
    DR(Label.DR),
    HON(Label.HON),
    JR(Label.JR),
    MR(Label.MR),
    MRS(Label.MRS),
    MS(Label.MS),
    PROF(Label.PROF),
    SR(Label.SR),
    ST(Label.ST);

    public class Label {
        public static final String DR = "Dr.";
        public static final String HON = "Hon.";
        public static final String JR = "Jr.";
        public static final String MR = "Mr.";
        public static final String MRS = "Mrs.";
        public static final String MS = "Ms.";
        public static final String PROF = "Prof.";
        public static final String SR = "Sr.";
        public static final String ST = "St.";
    }

    private final String label;

    private Title(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }

}
