package com.demo.courier.repo.user;

import com.demo.courier.entity.centre.Centre;
import com.demo.courier.entity.user.AppUser;
import com.demo.courier.entity.user.employee.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<AppUser, Integer> {

    @Query("SELECT au FROM AppUser au LEFT JOIN Employee e ON au.id = e.id WHERE e.id IS NULL")
    List<AppUser> findAllCustomers();

    @Query("SELECT e FROM AppUser au JOIN Employee e ON au.id = e.id")
    List<Employee> findAllEmployees();

    @Query("SELECT e FROM AppUser au JOIN Employee e ON au.id = e.id WHERE e.centre = :centre")
    List<Employee> findAllEmployees(Centre centre);

    Optional<AppUser> findByEmail(String email);

}
