package com.demo.courier.entity.consignment;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public enum State {
    COLLECTED(Label.COLLECTED),
    READY_FOR_SHIPPING(Label.READY_FOR_SHIPPING),
    IN_TRANSIT(Label.IN_TRANSIT),
    ARRIVED(Label.ARRIVED),
    READY_FOR_DELIVERY(Label.READY_FOR_DELIVERY),
    OUT_FOR_DELIVERY(Label.OUT_FOR_DELIVERY),
    DELIVERY_ATTEMPTED(Label.DELIVERY_ATTEMPTED),
    DELIVERED(Label.DELIVERED);

    public class Label {
        public static final String COLLECTED = "Collected";
        public static final String READY_FOR_SHIPPING = "Ready for Shipping";
        public static final String IN_TRANSIT = "In-transit";
        public static final String ARRIVED = "Arrived at Facility";
        public static final String READY_FOR_DELIVERY = "Ready for Delivery";
        public static final String OUT_FOR_DELIVERY = "Out for Delivery";
        public static final String DELIVERY_ATTEMPTED = "Delivery Attempted";
        public static final String DELIVERED = "Delivered";
    }

    private final String label;
    private static final Map<State, List<State>> STATE_MACHINE = initStateMachine();

    private static Map<State, List<State>> initStateMachine() {
        final Map<State, List<State>> map = new HashMap<>();
        map.put(null, List.of(COLLECTED));
        map.put(COLLECTED, List.of(READY_FOR_SHIPPING, READY_FOR_DELIVERY));
        map.put(READY_FOR_SHIPPING, List.of(IN_TRANSIT));
        map.put(IN_TRANSIT, List.of(IN_TRANSIT, ARRIVED));
        map.put(ARRIVED, List.of(READY_FOR_DELIVERY));
        map.put(READY_FOR_DELIVERY, List.of(OUT_FOR_DELIVERY));
        map.put(OUT_FOR_DELIVERY, List.of(DELIVERY_ATTEMPTED, DELIVERED));
        map.put(DELIVERY_ATTEMPTED, List.of(OUT_FOR_DELIVERY));
        map.put(DELIVERED, List.of());
        return map;
    }

    private State(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }

    public static List<State> next(State state) {
        return STATE_MACHINE.get(state);
    }

}
