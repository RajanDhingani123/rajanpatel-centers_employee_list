package com.demo.courier.repo.readonly;

import com.demo.courier.entity.view.CustomerInfo;

public interface CustomerInfoRepository extends ReadOnlyRepository<CustomerInfo, Integer> {

}
