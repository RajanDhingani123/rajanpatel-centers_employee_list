package com.demo.courier.entity.centre;

import com.demo.courier.entity.location.PinCode;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.List;

@NoArgsConstructor
@Getter @Setter @ToString
@Table(name = "courier_centre")
@Entity
public class Centre {

    @Id
    @SequenceGenerator(name = "sg_courier_centre_id", sequenceName = "sq_courier_centre_id", initialValue = 10, allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sg_courier_centre_id")
    private Integer id;

    @Column(nullable = false, length = 50)
    private String name;

    @Column(nullable = false)
    private Double latitude;

    @Column(nullable = false)
    private Double longitude;

    @Column(nullable = false, length = 100)
    private String addressLine1;

    @Column(length = 100)
    private String addressLine2;

    @ManyToOne
    @JoinColumn(name = "pin_code_id", nullable = false, foreignKey = @ForeignKey(name = "fk_courier_centre_pin_code_id"))
    private PinCode pinCode;

    @JsonIgnore
    @OneToMany(mappedBy = "centre")
    private List<Contact> contacts;

    public Centre(int id) {
        this.id = id;
    }

}
