package com.demo.courier.exception;

public class InvalidRequestException extends RuntimeException {

    public InvalidRequestException(String message, Object... args) {
        super("BAD REQUEST: " + String.format(message, args));
    }

}
