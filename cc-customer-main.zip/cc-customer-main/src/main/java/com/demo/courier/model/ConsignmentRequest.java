package com.demo.courier.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDate;

@Getter @Setter @ToString
public class ConsignmentRequest {

    private int senderId;

    private int receiverId;

    private boolean insured;

    private double billedAmount;

    private LocalDate billedDate;

    private Double weight;

    private Double length;

    private Double width;

    private Double height;

}
