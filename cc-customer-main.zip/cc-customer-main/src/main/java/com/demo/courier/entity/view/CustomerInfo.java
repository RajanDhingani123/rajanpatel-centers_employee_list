package com.demo.courier.entity.view;

import com.demo.courier.entity.user.Gender;
import com.demo.courier.entity.user.Title;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import org.hibernate.annotations.Immutable;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import java.time.LocalDate;

@Getter
@Immutable
@Entity
public class CustomerInfo {

    @Id
    private Integer id;

    private String email;

    @Enumerated(EnumType.STRING)
    private Title title;

    private String firstName;

    private String middleName;

    private String lastName;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateOfBirth;

    private String phone;

    @Enumerated(EnumType.STRING)
    private Gender gender;

    private Double latitude;

    private Double longitude;

    private String addressLine1;

    private String addressLine2;

    private String pinCodeId;

    private String pin;

    private int cityId;

    private String city;

    private String state;

    private String country;

}
