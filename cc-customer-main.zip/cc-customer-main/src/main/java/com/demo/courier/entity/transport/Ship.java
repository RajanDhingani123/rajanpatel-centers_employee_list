package com.demo.courier.entity.transport;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@DiscriminatorValue(TransportType.Label.SHIP)
@Entity
public class Ship extends Vehicle {
}
