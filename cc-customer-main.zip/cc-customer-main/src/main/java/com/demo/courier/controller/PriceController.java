package com.demo.courier.controller;

import com.demo.courier.model.InsurancePrice;
import com.demo.courier.model.Item;
import com.demo.courier.model.ItemPrice;
import com.demo.courier.service.PriceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/prices")
@RestController
public class PriceController {

    @Autowired
    private PriceService priceService;

    @PostMapping(value = "/shipping", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody double calculateShippingPrice(@RequestBody Item item) {
        return priceService.shippingPrice(item.getSource(),
                item.getDestination(),
                item.getWeight());
    }

    @PostMapping("/insurance")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody InsurancePrice calculateInsurancePrice(@RequestBody ItemPrice itemPrice) {
        return priceService.insurancePrice(itemPrice.getBilledAmount(), itemPrice.getBilledDate());
    }

}
