package com.demo.courier.controller;

import com.demo.courier.entity.centre.Centre;
import com.demo.courier.entity.centre.Contact;
import com.demo.courier.entity.view.CentreInfo;
import com.demo.courier.exception.NotAllowedException;
import com.demo.courier.service.CentreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/centres")
@RestController
public class CentreController {

    @Autowired
    private CentreService centreService;

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody List<CentreInfo> fetchCentres() {
        return centreService.fetchCentres();
    }

    @GetMapping("/{centreId}")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody Centre fetchCentre(@PathVariable int centreId) {
        return centreService.fetchCentre(centreId);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public @ResponseBody Centre createCentre(@RequestBody Centre centre) {
        centre.setId(null);
        return centreService.createCentre(centre);
    }

    @PutMapping("/{centreId}")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody Centre updateCentre(@PathVariable int centreId, @RequestBody Centre centre) {
        centre.setId(centreId);
        return centreService.updateCentre(centre);
    }

    @DeleteMapping("/{centreId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public @ResponseBody void deleteCentre(@PathVariable int centreId) {
        if (centreId <= 0)
            throw new NotAllowedException("centre=%d", centreId);
        centreService.deleteCentre(centreId);
    }

    @GetMapping("/{centreId}/contacts")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody List<Contact> fetchContacts(@PathVariable int centreId) {
        return centreService.fetchContacts(centreId);
    }

    @PostMapping("/{centreId}/contacts")
    @ResponseStatus(HttpStatus.CREATED)
    public @ResponseBody Contact createContact(@RequestBody Contact contact) {
        return centreService.addContact(contact);
    }

    @DeleteMapping("/{centreId}/contacts/{phone}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public @ResponseBody void deleteContact(@PathVariable String phone) {
        centreService.deleteContact(phone);
    }

}
