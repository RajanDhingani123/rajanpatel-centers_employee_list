package com.demo.courier.exception;

public class NotFoundException extends RuntimeException {

    public NotFoundException(String message, Object... args) {
        super("NOT FOUND: " + String.format(message, args));
    }

}
