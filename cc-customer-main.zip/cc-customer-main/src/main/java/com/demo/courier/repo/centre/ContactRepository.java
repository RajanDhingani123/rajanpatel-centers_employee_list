package com.demo.courier.repo.centre;

import com.demo.courier.entity.centre.Centre;
import com.demo.courier.entity.centre.Contact;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ContactRepository extends JpaRepository<Contact, String> {

    List<Contact> findAllByCentre(Centre centre);

}
