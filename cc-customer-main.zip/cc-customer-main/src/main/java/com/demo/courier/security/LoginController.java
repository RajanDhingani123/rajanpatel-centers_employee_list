package com.demo.courier.security;

import com.demo.courier.entity.centre.Centre;
import com.demo.courier.entity.location.City;
import com.demo.courier.entity.user.AppUser;
import com.demo.courier.entity.user.employee.Employee;
import com.demo.courier.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RequestMapping("/login")
@RestController
public class LoginController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private UserService userService;

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody String tryLogin(@RequestBody LoginRequest login) {
        final Authentication authentication =
                new UsernamePasswordAuthenticationToken(login.getUsername(), login.getPassword());
        authenticationManager.authenticate(authentication);
        final UserDetails userDetails = userDetailsService.loadUserByUsername(login.getUsername());
        AppUser user = userService.fetchUser(Integer.parseInt(userDetails.getUsername()));
        final Map<String, Object> claims = new HashMap<>();
        claims.put("firstName", user.getFirstName());
        claims.put("lastName", user.getLastName());
        for(GrantedAuthority authority :userDetails.getAuthorities()) {
            if(authority.getAuthority().startsWith("ROLE_")) {
                final String role = authority.getAuthority().substring(5);
                claims.put("role", role);
                if("EMPLOYEE".equals(role)) {
                    final Employee employee = (Employee) user;
                    final Centre centre = employee.getCentre();
                    claims.put("centreId", centre.getId());
                    claims.put("centreName", centre.getName());
                    final City city = centre.getPinCode().getCity();
                    claims.put("centreCityId", city.getId());
                    claims.put("centreCityName", city.getName());
                }
            } else
                claims.put("authority", authority.getAuthority().substring(0, authority.getAuthority().length()-"_AUTHORITY".length()));
        }
        return JwtTokenUtil.generateToken(userDetails, claims);
    }

}
