package com.demo.courier.entity.view;

import com.demo.courier.entity.consignment.State;
import com.demo.courier.entity.transport.TransportType;
import lombok.Getter;
import org.hibernate.annotations.Immutable;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import java.time.Instant;
import java.util.UUID;

@Getter
@Immutable
@Entity(name = "consignment_status_info")
public class StatusInfo {

    @Id
    private Integer id;

    @Enumerated(EnumType.STRING)
    private State status;

    private Instant timestamp;

    private UUID consignmentId;

    private String city;

    private String state;

    private String country;

    @Enumerated(EnumType.STRING)
    private TransportType vehicleType;

    private String vehicleNumber;

}
