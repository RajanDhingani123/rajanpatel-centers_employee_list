package com.demo.courier.entity.location;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

@Getter @Setter @ToString
@Table(uniqueConstraints = @UniqueConstraint(columnNames = {"country_id", "pin"}, name = "uk_pin_code_country_id_pin"))
@Entity
public class PinCode {

    @Id
    @Column(length = 20)
    private String id;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "country_id", nullable = false, foreignKey = @ForeignKey(name = "fk_pin_code_country_id"))
    private Country country;

    @Column(nullable = false, length = 10)
    private String pin;

    @Column(nullable = false, length = 100)
    private String areaName;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "city_id", nullable = false, foreignKey = @ForeignKey(name = "fk_pin_code_city_id"))
    private City city;

}
