package com.demo.courier.service.impl;

import com.demo.courier.entity.transport.TransportType;
import com.demo.courier.entity.transport.Vehicle;
import com.demo.courier.exception.NotFoundException;
import com.demo.courier.model.Enum;
import com.demo.courier.repo.transport.VehicleRepository;
import com.demo.courier.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class VehicleServiceImpl implements VehicleService {

    @Autowired
    private VehicleRepository vehicleRepository;

    @Override
    public List<Vehicle> fetchVehicles() {
        return vehicleRepository.findAll();
    }

    @Override
    public Vehicle fetchVehicle(long vehicleId) {
        Optional<Vehicle> vehicle = vehicleRepository.findById(vehicleId);
        if (vehicle.isEmpty())
            throw new NotFoundException("vehicle=%d", vehicle);
        return vehicle.get();
    }

    @Override
    public Vehicle addVehicle(Vehicle vehicle) {
        return vehicleRepository.save(vehicle);
    }

    @Override
    public List<Enum> fetchVehicleTypes() {
        return Stream.of(TransportType.values())
                .map(type -> new Enum(type.name(), type.label()))
                .collect(Collectors.toList());
    }

}
