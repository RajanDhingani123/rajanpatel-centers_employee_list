package com.demo.courier.repo.readonly;

import com.demo.courier.entity.view.CentreInfo;

public interface CentreInfoRepository extends ReadOnlyRepository<CentreInfo, Integer> {

}
