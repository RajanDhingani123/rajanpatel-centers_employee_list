package com.demo.courier.exception;

public class NotAllowedException extends RuntimeException {

    public NotAllowedException(String message, Object... args) {
        super("NOT ALLOWED: " + String.format(message, args));
    }

}
