package com.demo.courier.service.impl;

import com.demo.courier.entity.location.City;
import com.demo.courier.model.InsurancePrice;
import com.demo.courier.repo.location.CityRepository;
import com.demo.courier.service.PriceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.Period;

@Service
public class PriceServiceImpl implements PriceService {

    private final double BASE_PRICE = 100.0;
    private final double RATE_KM = 0.1;
    private final double RATE_KG = 0.2;
    private final double DEPRECIATION_MONTH = 0.1;

    private final double INSURANCE_FACTOR = 0.05;

    @Autowired
    private CityRepository cityRepository;

    @Override
    public Double shippingPrice(City source, City destination, double weight) {
        source = cityRepository.getById(source.getId());
        destination = cityRepository.getById(destination.getId());
        double price = BASE_PRICE;
        double km = distance(source, destination);
        if (km < 30)
            km = 30;
        if (weight <= 1)
            price += km * RATE_KM;
        else
            price += km * RATE_KG * weight;
        return Math.ceil(price / 10) * 10.0;
    }

    @Override
    public InsurancePrice insurancePrice(Double billedAmount, LocalDate billDate) {
        final int months = Period.between(billDate, LocalDate.now()).getMonths();
        double depreciatedValue = billedAmount * (1 - months * DEPRECIATION_MONTH);
        if (depreciatedValue < billedAmount / 10)
            depreciatedValue = billedAmount / 10;
        return new InsurancePrice(depreciatedValue * INSURANCE_FACTOR, depreciatedValue);
    }

    private double distance(City source, City destination) {
        final int R = 6371;
        final double lat1 = degree2Radian(source.getLatitude());
        final double long1 = degree2Radian(source.getLongitude());
        final double lat2 = degree2Radian(destination.getLatitude());
        final double long2 = degree2Radian(destination.getLongitude());
        double dist = Math.acos(Math.sin(lat1) * Math.sin(lat2) + Math.cos(lat1) * Math.cos(lat2) * Math.cos(long2 - long1)) * R;
        return Math.ceil(dist);
    }

    private double degree2Radian(double degree) {
        return degree * Math.PI / 180;
    }

}
