package com.demo.courier.handler;

import com.demo.courier.security.AuthUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Random;


public class LoggerInterceptor implements HandlerInterceptor {

    private static final Logger logger = LoggerFactory.getLogger(LoggerInterceptor.class);

    private static final Random random = new Random();

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        Thread.sleep(500 + random.nextInt(1000)); // Simulate a slow request
        logger.info("Request by: {} = {} {}", AuthUtil.getUsername(), request.getMethod(), request.getRequestURI());
        return true;
    }

}
