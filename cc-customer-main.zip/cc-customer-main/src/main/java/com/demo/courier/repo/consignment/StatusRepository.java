package com.demo.courier.repo.consignment;

import com.demo.courier.entity.consignment.Consignment;
import com.demo.courier.entity.consignment.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StatusRepository extends JpaRepository<Status, Long> {

    List<Status> findAllByConsignment(Consignment consignment);

    Status findTopByConsignmentOrderByTimestampDesc(Consignment consignment);

}
