package com.demo.courier.entity.user;

import com.demo.courier.entity.location.PinCode;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDate;

@NoArgsConstructor
@Getter @Setter @ToString
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "app_user", uniqueConstraints = @UniqueConstraint(columnNames = "email", name = "uk_app_user_email"))
@Entity
public class AppUser {

    @Id
    @SequenceGenerator(name = "sg_app_user_id", sequenceName = "sq_app_user_id", initialValue = 100000, allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sg_app_user_id")
    private Integer id;

    @Column(nullable = false, length = 100)
    private String email;

    @Enumerated(EnumType.STRING)
    @Column(length = 20)
    private Title title;

    @Column(nullable = false, length = 50)
    private String firstName;

    @Column(length = 50)
    private String middleName;

    @Column(length = 50)
    private String lastName;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column
    private LocalDate dateOfBirth;

    @Column(nullable = false, length = 20)
    private String phone;

    @Enumerated(EnumType.STRING)
    @Column(length = 20)
    private Gender gender;

    private Double latitude;

    private Double longitude;

    @Column(nullable = false, length = 100)
    private String addressLine1;

    @Column(length = 100)
    private String addressLine2;

    @ManyToOne
    @JoinColumn(name = "pin_code_id", nullable = false, foreignKey = @ForeignKey(name = "fk_app_user_pin_code_id"))
    private PinCode pinCode;

    public AppUser(int id) {
        this.id = id;
    }

}
