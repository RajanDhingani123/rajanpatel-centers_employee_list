package com.demo.courier.entity.location;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Getter @Setter @ToString
@Entity
public class Country {

    @Id
    @Column
    private Integer id;

    @Column(nullable = false, length = 50)
    private String name;

}
