package com.demo.courier.service.impl;

import com.demo.courier.entity.centre.Centre;
import com.demo.courier.entity.user.AppUser;
import com.demo.courier.entity.user.Credential;
import com.demo.courier.entity.user.Title;
import com.demo.courier.entity.user.employee.Designation;
import com.demo.courier.entity.user.employee.Employee;
import com.demo.courier.entity.view.CustomerInfo;
import com.demo.courier.entity.view.EmployeeInfo;
import com.demo.courier.exception.NotFoundException;
import com.demo.courier.model.Enum;
import com.demo.courier.repo.readonly.CustomerInfoRepository;
import com.demo.courier.repo.readonly.EmployeeInfoRepository;
import com.demo.courier.repo.user.CredentialRepository;
import com.demo.courier.repo.user.UserRepository;
import com.demo.courier.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CustomerInfoRepository customerInfoRepository;

    @Autowired
    private EmployeeInfoRepository employeeInfoRepository;

    @Autowired
    private CredentialRepository credentialRepository;

    @Override
    public List<CustomerInfo> fetchCustomers() {
        return customerInfoRepository.findAll();
    }

    @Override
    public List<EmployeeInfo> fetchEmployees() {
        return employeeInfoRepository.findAll();
    }

    @Override
    public List<Employee> fetchEmployees(Centre centre) {
        return userRepository.findAllEmployees(centre);
    }

    @Transactional
    @Override
    public AppUser createCustomer(AppUser customer) {
        AppUser user = userRepository.save(customer);
        final Credential credential = new Credential();
        credential.setPass("User@123");
        credential.setAppUser(user);
        credentialRepository.save(credential);
        return user;
    }

    @Transactional
    @Override
    public Employee createEmployee(AppUser employee) {
        final Employee user = (Employee) userRepository.save(employee);
        final Credential credential = new Credential();
        credential.setPass("Emp@1234");
        credential.setAppUser(user);
        credentialRepository.save(credential);
        return user;
    }

    @Override
    public AppUser fetchUser(int id) {
        Optional<AppUser> user = userRepository.findById(id);
        if (user.isEmpty())
            throw new NotFoundException("user=%d", id);
        return user.get();
    }

    @Override
    public void updateEmployees(List<Employee> employees) {
        userRepository.saveAll(employees);
    }

    @Override
    public List<Enum> fetchTitles() {
        return Stream.of(Title.values())
                .map(title -> new Enum(title.name(), title.label()))
                .collect(Collectors.toList());
    }

    @Override
    public List<Enum> fetchDesignations() {
        return Stream.of(Designation.values())
                .map(designation -> new Enum(designation.name(), designation.label()))
                .collect(Collectors.toList());
    }

}
